function App() {
  return (
    <ul>
      <li>
        <a href="minimal">Minimal uploader</a>
      </li>
      <li>
        <a href="regular">Regular uploader</a>
      </li>
    </ul>
  );
}

export default App;
