declare module '*?raw' {
  const contents: string;
  export = contents;
}

declare module '*?url' {
  const url: string;
  export = url;
}
