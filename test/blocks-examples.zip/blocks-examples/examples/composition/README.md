# Blocks composition examples

[![Edit composition](https://codesandbox.io/static/img/play-codesandbox.svg)](https://codesandbox.io/s/github/uploadcare/blocks-examples/tree/main/examples/composition/)


## Run this demo locally

```bash
# clone this repo and go to the cloned folder

$ cd examples/composition

$ npm install
# or `yarn install`, if you wish

$ npm run start
# or `yarn start`
```
